package com.refactorlabs.cs378.sessions;

import com.sun.tools.javac.code.Attribute;
import com.sun.tools.javac.util.Convert;
import org.apache.avro.Schema;
import org.apache.avro.mapred.AvroKey;
import org.apache.avro.mapreduce.AvroKeyValueInputFormat;
import org.apache.avro.mapreduce.AvroKeyValueOutputFormat;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.MRJobConfig;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.avro.mapred.AvroValue;
import org.apache.avro.mapreduce.AvroJob;
import java.net.URL;
import java.net.URLClassLoader;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.*;

import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;



public class UserSessions extends Configured implements Tool{

	
	public final static LongWritable ONE = new LongWritable(1L);


	/**
	 * The Reduce class. Extends class Reducer, provided by Hadoop.
	 */
	public static class ReduceClass extends Reducer<Text, AvroValue<Session>, AvroKey<CharSequence>, AvroValue<Session>> {

		/**
		 * Counter group for the reducer.  Individual counters are grouped for the reducer.
		 */
		private static final String REDUCER_COUNTER_GROUP = "Reducer Counts";

		@Override
		public void reduce(Text key, Iterable<AvroValue<Session>> values, Context context)
				throws IOException, InterruptedException {

			context.getCounter(REDUCER_COUNTER_GROUP, "Words Out").increment(1L);

			Session.Builder builder = Session.newBuilder();
			List<Event> allEvents = new ArrayList<Event>();
			builder.setUserId(key.toString());

			// Sum up the counts for the current word, specified in object "key".
			for (AvroValue<Session> value : values) {
				List<Event> event = value.datum().getEvents();
				for (int i=0; i<event.size(); i++){
					allEvents.add(Event.newBuilder(event.get(i)).build());
				}
			}
			builder.setEvents(allEvents);
			CharSequence myKey = key.toString();

			// Emit the total count for the word.
			context.write(new AvroKey<CharSequence>(myKey), new AvroValue<Session>(builder.build()));
		}
	}

	public int run(String[] args) throws Exception {
		if (args.length != 2) {
			System.err.println("Usage: WordStatistics <input path> <output path>");
			return -1;
		}

		Configuration conf = getConf();

		// Use this JAR first in the classpath (We also set a bootstrap script in AWS)
		conf.setBoolean(MRJobConfig.MAPREDUCE_JOB_USER_CLASSPATH_FIRST, true);

		Job job = Job.getInstance(conf, "UserSessions");
		String[] appArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

		// Identify the JAR file to replicate to all machines.
		job.setJarByClass(UserSessions.class);

		// Specify the Map

		job.setInputFormatClass(AvroKeyValueInputFormat.class);
		job.setMapperClass(AvroMapper.class);
		AvroJob.setMapOutputValueSchema(job, Session.getClassSchema());
		AvroJob.setMapOutputKeySchema(job, Schema.create(Schema.Type.STRING));
		AvroJob.setInputKeySchema(job, Schema.create(Schema.Type.STRING));
		AvroJob.setInputValueSchema(job, Session.getClassSchema());

		/*
		job.setInputFormatClass(TextInputFormat.class);
		job.setMapperClass(MapClass.class);
		job.setMapOutputKeyClass(Text.class);
		AvroJob.setMapOutputValueSchema(job, Session.getClassSchema());
*/
		// Specify the Reduce
		job.setOutputFormatClass(AvroKeyValueOutputFormat.class);
		//job.setOutputKeyClass(CharSequence.class);
		//AvroJob.setOutputValueSchema(job, VinImpressionCounts.getClassSchema());
		AvroJob.setOutputKeySchema(job, Schema.create(Schema.Type.STRING));
		AvroJob.setOutputValueSchema(job, Session.getClassSchema());

		// Grab the input file and output directory from the command line.
		org.apache.avro.mapreduce.AvroMultipleOutputs.setCountersEnabled(job, true);

		org.apache.avro.mapreduce.AvroMultipleOutputs.addNamedOutput(job, SessionType.SUBMITTER.getText(), AvroKeyValueOutputFormat.class, Schema.create(Schema.Type.STRING),Session.getClassSchema());
		org.apache.avro.mapreduce.AvroMultipleOutputs.addNamedOutput(job, SessionType.CPO.getText(), AvroKeyValueOutputFormat.class, Schema.create(Schema.Type.STRING),Session.getClassSchema());
		org.apache.avro.mapreduce.AvroMultipleOutputs.addNamedOutput(job, SessionType.CLICKER.getText(), AvroKeyValueOutputFormat.class, Schema.create(Schema.Type.STRING),Session.getClassSchema());
		org.apache.avro.mapreduce.AvroMultipleOutputs.addNamedOutput(job, SessionType.SHOWER.getText(), AvroKeyValueOutputFormat.class, Schema.create(Schema.Type.STRING),Session.getClassSchema());
		org.apache.avro.mapreduce.AvroMultipleOutputs.addNamedOutput(job, SessionType.VISITOR.getText(), AvroKeyValueOutputFormat.class, Schema.create(Schema.Type.STRING),Session.getClassSchema());
		org.apache.avro.mapreduce.AvroMultipleOutputs.addNamedOutput(job, SessionType.OTHER.getText(), AvroKeyValueOutputFormat.class, Schema.create(Schema.Type.STRING), Session.getClassSchema());

		//MultipleInputs.addInputPath(job, new Path(appArgs[0]),AvroKeyValueInputFormat.class,AvroMapper.class);
		//MultipleInputs.addInputPath(job, new Path(appArgs[1]),TextInputFormat.class,CSVMapper.class);
		FileInputFormat.addInputPaths(job, appArgs[0]);
		FileOutputFormat.setOutputPath(job, new Path(appArgs[1]));

		// Initiate the map-reduce job, and wait for completion.
		job.waitForCompletion(true);

		return 0;
	}

	public static void printClassPath() {
		ClassLoader cl = ClassLoader.getSystemClassLoader();
		URL[] urls = ((URLClassLoader) cl).getURLs();
		System.out.println("classpath BEGIN");
		for (URL url : urls) {
			System.out.println(url.getFile());
		}
		System.out.println("classpath END");
		System.out.flush();
	}
	/**
	 * The main method specifies the characteristics of the map-reduce job
	 * by setting values on the Job object, and then initiates the map-reduce
	 * job and waits for it to complete.
	 */
	public static void main(String[] args) throws Exception {
		printClassPath();
		int res = ToolRunner.run(new Configuration(), new UserSessions(), args);
		System.exit(res);
	}
}
