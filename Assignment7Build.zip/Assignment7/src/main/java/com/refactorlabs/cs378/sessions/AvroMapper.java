package com.refactorlabs.cs378.sessions;

import com.sun.tools.javac.code.Attribute;
import com.sun.tools.javac.util.Convert;
import org.apache.avro.mapred.AvroKey;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.MRJobConfig;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.avro.mapred.AvroValue;
import org.apache.avro.mapreduce.AvroJob;
import java.net.URL;
import java.net.URLClassLoader;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.*;

import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/**
 * Created by asad on 10/31/2015.
 */

//The Map class for avro file.  Extends class Mapper, provided by Hadoop.
public class AvroMapper extends Mapper<AvroKey<CharSequence>, AvroValue<Session>, Text, AvroValue<VinImpressionCounts>> {

        /**
         * Counter group for the mapper.  Individual counters are grouped for the mapper.
         */
        private static final String MAPPER_COUNTER_GROUP = "Mapper Counts";

        /**
         * Local variable "word" will contain the word identified in the input.
         * The Hadoop Text object is mutable, so we can reuse the same object and
         * simply reset its value as each word in the input is encountered.
         */
        private Text word = new Text();


        @Override
        public void map(AvroKey<CharSequence> key, AvroValue<Session> value, Context context)
                throws IOException, InterruptedException {

            VinImpressionCounts.Builder Builder = VinImpressionCounts.newBuilder();
            List<Event> event = new ArrayList<Event>();
            event=value.datum().getEvents();
            Map<CharSequence,Integer>wordCountMap=new HashMap<CharSequence,Integer>();

            Map<CharSequence,Map<CharSequence,Long>>ClickCountMap=new HashMap<CharSequence,Map<CharSequence,Long>>();

            Map<CharSequence,Long>ShowCountMap=new HashMap<CharSequence,Long>();

            Map<CharSequence,Long>EditCountMap=new HashMap<CharSequence,Long>();

            Map<CharSequence,Long>SubmitCountMap=new HashMap<CharSequence,Long>();

            Map<CharSequence,VinImpressionCounts.Builder> VinMap= new HashMap<CharSequence,VinImpressionCounts.Builder>();

            for(Event myevent: event){
                CharSequence store=myevent.getVin();
                VinImpressionCounts.Builder temp1 = VinImpressionCounts.newBuilder();

                if(!(wordCountMap.containsKey(store))) {
                    wordCountMap.put(store, 1);
                    temp1.setUniqueUser(1);
                }
                else{
                    wordCountMap.put(store, wordCountMap.get(store)+1);
                    temp1.setUniqueUser(wordCountMap.get(store)+1);
                }

                if(myevent.getEventType().equals(EventType.CLICK)) {
                    Map<CharSequence,Long>temp=new HashMap<CharSequence,Long>();
                    CharSequence eventsubtype = myevent.getEventSubtype().name();
                    if(!(ClickCountMap.containsKey(store))) {
                        temp.put(eventsubtype, 1L);
                        ClickCountMap.put(store, temp);
                        temp1.setClicks(temp);
                    }
                    else{
                        temp=ClickCountMap.get(store);
                        temp.put(eventsubtype, 1L);
                        ClickCountMap.put(store, temp);
                        temp1.setClicks(temp);
                    }
                }

                if(myevent.getEventType().equals(EventType.SHOW)){
                    if(myevent.getEventSubtype().equals(EventSubtype.BADGE_DETAIL)){
                        if(!(ShowCountMap.containsKey(store))){
                            ShowCountMap.put(store,1L);
                            temp1.setShowBadgeDetail(1L);
                        }
                    }
                }

                if(myevent.getEventType().equals(EventType.EDIT)){
                    if(myevent.getEventSubtype().equals(EventSubtype.CONTACT_FORM)){
                        if(!(EditCountMap.containsKey(store))){
                            EditCountMap.put(store,1L);
                            temp1.setEditContactForm(1L);
                        }
                    }
                }

                if(myevent.getEventType().equals(EventType.SUBMIT)){
                    if(myevent.getEventSubtype().equals(EventSubtype.CONTACT_FORM)){
                        if(!(ShowCountMap.containsKey(store))){
                            SubmitCountMap.put(store,1L);
                            temp1.setSubmitContactForm(1L);
                        }
                    }
                }

                VinMap.put(store,temp1);
            }

            for(CharSequence next : VinMap.keySet()){
                word.set(next.toString());
                VinImpressionCounts.Builder temp = VinImpressionCounts.newBuilder();
                temp = VinMap.get(next);
                context.write(word,new AvroValue<VinImpressionCounts>(temp.build()));
            }


        }
}
