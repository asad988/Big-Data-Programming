package com.refactorlabs.cs378.sessions;

import org.apache.avro.mapred.AvroKey;
import org.apache.avro.mapred.AvroValue;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by asad on 11/2/2015.
 */
public class vinReduce extends Reducer<Text, AvroValue<VinImpressionCounts>, AvroKey<CharSequence>, AvroValue<VinImpressionCounts>> {

    /**
     * Counter group for the reducer.  Individual counters are grouped for the reducer.
     */
    private static final String REDUCER_COUNTER_GROUP = "Reducer Counts";

    @Override
    public void reduce(Text key, Iterable<AvroValue<VinImpressionCounts>> values, Context context)
            throws IOException, InterruptedException {

        context.getCounter(REDUCER_COUNTER_GROUP, "Words Out").increment(1L);

        VinImpressionCounts.Builder builder = VinImpressionCounts.newBuilder();
        List<VinImpressionCounts> ListA = new ArrayList<VinImpressionCounts>();
        List<VinImpressionCounts> ListB = new ArrayList<VinImpressionCounts>();

        // Sum up the counts for the current word, specified in object "key".
        for (AvroValue<VinImpressionCounts> value : values) {
            if(value.datum().getUniqueUser()!=0){
                ListA.add(value.datum());
                builder.setUniqueUser(value.datum().getUniqueUser());
                builder.setClicks(value.datum().getClicks());
                builder.setSubmitContactForm(value.datum().getSubmitContactForm());
                builder.setEditContactForm(value.datum().getEditContactForm());
                builder.setShowBadgeDetail(value.datum().getShowBadgeDetail());
            }
            else{
                ListB.add(value.datum());
                builder.setMarketplaceVdps(value.datum().getMarketplaceVdps());
                builder.setMarketplaceSrps(value.datum().getMarketplaceSrps());
            }

            CharSequence myKey = key.toString();

            // Emit the total count for the word.
            if(builder.getUniqueUser()!=0) {
                context.write(new AvroKey<CharSequence>(myKey), new AvroValue<VinImpressionCounts>(builder.build()));
            }

        }

    }
}
