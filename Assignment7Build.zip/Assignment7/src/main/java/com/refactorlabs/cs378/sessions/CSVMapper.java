package com.refactorlabs.cs378.sessions;

import com.sun.tools.javac.code.Attribute;
import com.sun.tools.javac.util.Convert;
import org.apache.avro.mapred.AvroKey;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.MRJobConfig;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.avro.mapred.AvroValue;
import org.apache.avro.mapreduce.AvroJob;
import java.net.URL;
import java.net.URLClassLoader;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.*;

import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/**
 * Created by asad on 10/31/2015.
 */
//The Map class for csv file.  Extends class Mapper, provided by Hadoop.
    public class CSVMapper extends Mapper<LongWritable, Text, Text, AvroValue<VinImpressionCounts>> {
        /**
         * Counter group for the mapper.  Individual counters are grouped for the mapper.
         */
        private static final String MAPPER_COUNTER_GROUP = "Mapper Counts";

        /**
         * Local variable "word" will contain the word identified in the input.
         * The Hadoop Text object is mutable, so we can reuse the same object and
         * simply reset its value as each word in the input is encountered.
         */
        private Text word = new Text();
        public static boolean i=false;


        @Override
        public void map(LongWritable key, Text value, Context context)
                throws IOException, InterruptedException {
            //we don't want to read the header line of the csv
            String token = value.toString();
            String[] store = token.split(",");
            if(!(store[0].contains("vin"))) {
                //seperate string and assign values
                VinImpressionCounts.Builder Builder = VinImpressionCounts.newBuilder();
                if (store[1].contains("SRP")) {
                    Builder.setMarketplaceSrps(Long.parseLong(store[2]));
                } else {
                    Builder.setMarketplaceVdps(Long.parseLong(store[2]));
                }
                word.set(store[0]);
                context.write(word, new AvroValue<VinImpressionCounts>(Builder.build()));
            }
        }
    }

