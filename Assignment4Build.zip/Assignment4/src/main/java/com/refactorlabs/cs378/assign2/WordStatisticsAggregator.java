package com.refactorlabs.cs378.assign2;

import com.sun.tools.javac.util.Convert;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.IOException;
import java.util.StringTokenizer;

/**
 * Created by asad on 10/4/2015.
 */
public class WordStatisticsAggregator extends WordStatistics{

    public static class AggMapClass extends Mapper<Text,Text,Text,WordStatisticsWritable>{

        @Override
        public void map(Text key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString();
            line=line.replace(","," ");
            StringTokenizer tokenizer = new StringTokenizer(line);
            int i=0;
            Long count=0L, freq=0L, freqSq = 0L;
            Double mean=0D, variance =0D;
            while(tokenizer.hasMoreTokens()){
                String next = tokenizer.nextToken();
                if(i==0){
                    count =  Long.parseLong(next);
                }
                else if(i==1){
                    freq = Long.parseLong(next);
                }
                else if(i==2){
                    freqSq = Long.parseLong(next);
                }
                i++;
            }
            //WordStatisticsWritable MapArrayval = new WordStatisticsWritable(new LongWritable(count), new LongWritable(freq), new LongWritable(freqSq), new DoubleWritable(mean), new DoubleWritable(variance));
            WordStatisticsWritable MapArrayval = new WordStatisticsWritable();
            MapArrayval.dCount=new LongWritable(count);
            MapArrayval.tCount=new LongWritable(freq);
            MapArrayval.SSq=new LongWritable(freqSq);
            MapArrayval.Mean=new DoubleWritable(mean);
            MapArrayval.variance=new DoubleWritable(variance);

            context.write(key,MapArrayval);
        }
    }

    public static void main(String [] args) throws Exception {
        Configuration conf = new Configuration();
        String[] appArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        Job job = new Job(conf, "WordStatistics");
        // Identify the JAR file to replicate to all machines.
        job.setJarByClass(WordStatisticsAggregator.class);

        // Set the output key and value types (for map and reduce).

        //map has different output values
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(WordStatisticsWritable.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(WordStatisticsWritable.class);
        //job.setMapOutputKeyClass(Text.class);
        //job.setMapOutputValueClass(LongArrayWritable.class);

        // Set the map and reduce classes.
        job.setMapperClass(AggMapClass.class);
        job.setReducerClass(ReduceClass.class);
        job.setCombinerClass(ReduceClass.class);

        // Set the input and output file formats.
        job.setInputFormatClass(KeyValueTextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);

        // Grab the input file and output directory from the command line.
        FileInputFormat.addInputPaths(job, appArgs[0]);
        FileOutputFormat.setOutputPath(job, new Path(appArgs[1]));

        // Initiate the map-reduce job, and wait for completion.
        job.waitForCompletion(true);
    }

}
