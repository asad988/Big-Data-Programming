package com.refactorlabs.cs378.sessions;

import com.sun.tools.javac.code.Attribute;
import com.sun.tools.javac.util.Convert;
import org.apache.avro.Schema;
import org.apache.avro.mapred.AvroKey;
import org.apache.avro.mapreduce.AvroKeyValueInputFormat;
import org.apache.avro.mapreduce.AvroKeyValueOutputFormat;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.MRJobConfig;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.avro.mapred.AvroValue;
import org.apache.avro.mapreduce.AvroJob;
import java.net.URL;
import java.net.URLClassLoader;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.*;

import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


/**
 * Example MapReduce program that performs word count.
 *
 * @author David Franke (dfranke@cs.utexas.edu)
 */
public class UserSessions extends Configured implements Tool{

	/**
	 * Each count output from the map() function is "1", so to minimize small
	 * object creation we can use a constant for this output value/object.
	 */
	public final static LongWritable ONE = new LongWritable(1L);


	/**
	 * The Reduce class for word count.  Extends class Reducer, provided by Hadoop.
	 * This class defines the reduce() function for the word count example.
	 */
	public static class ReduceClass extends Reducer<Text, AvroValue<Session>, AvroKey<CharSequence>, AvroValue<Session>> {

		/**
		 * Counter group for the reducer.  Individual counters are grouped for the reducer.
		 */
		private static final String REDUCER_COUNTER_GROUP = "Reducer Counts";

		@Override
		public void reduce(Text key, Iterable<AvroValue<Session>> values, Context context)
				throws IOException, InterruptedException {

			context.getCounter(REDUCER_COUNTER_GROUP, "Words Out").increment(1L);

			Session.Builder builder = Session.newBuilder();
			List<Event> allEvents = new ArrayList<Event>();
			builder.setUserId(key.toString());

			// Sum up the counts for the current word, specified in object "key".
			for (AvroValue<Session> value : values) {
				List<Event> event = value.datum().getEvents();
				for (int i=0; i<event.size(); i++){
					allEvents.add(Event.newBuilder(event.get(i)).build());
				}
			}
			builder.setEvents(allEvents);
			CharSequence myKey = key.toString();

			// Emit the total count for the word.
			context.write(new AvroKey<CharSequence>(myKey), new AvroValue<Session>(builder.build()));
		}
	}

	public int run(String[] args) throws Exception {
		if (args.length != 2) {
			System.err.println("Usage: WordStatistics <input path> <output path>");
			return -1;
		}

		Configuration conf = getConf();

		// Use this JAR first in the classpath (We also set a bootstrap script in AWS)
		conf.setBoolean(MRJobConfig.MAPREDUCE_JOB_USER_CLASSPATH_FIRST, true);

		Job job = Job.getInstance(conf, "UserSessions");
		String[] appArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

		// Identify the JAR file to replicate to all machines.
		job.setJarByClass(UserSessions.class);

		// Specify the Map

		job.setInputFormatClass(AvroKeyValueInputFormat.class);
		job.setMapperClass(AvroMapper.class);
		AvroJob.setMapOutputValueSchema(job, Session.getClassSchema());
		AvroJob.setMapOutputKeySchema(job, Schema.create(Schema.Type.STRING));
		AvroJob.setInputKeySchema(job, Schema.create(Schema.Type.STRING));
		AvroJob.setInputValueSchema(job, Session.getClassSchema());

		/*
		job.setInputFormatClass(TextInputFormat.class);
		job.setMapperClass(MapClass.class);
		job.setMapOutputKeyClass(Text.class);
		AvroJob.setMapOutputValueSchema(job, Session.getClassSchema());
*/
		// Specify the Reduce
		job.setOutputFormatClass(AvroKeyValueOutputFormat.class);
		//job.setOutputKeyClass(CharSequence.class);
		//AvroJob.setOutputValueSchema(job, VinImpressionCounts.getClassSchema());
		AvroJob.setOutputKeySchema(job, Schema.create(Schema.Type.STRING));
		AvroJob.setOutputValueSchema(job, Session.getClassSchema());

		// Grab the input file and output directory from the command line.
		org.apache.avro.mapreduce.AvroMultipleOutputs.setCountersEnabled(job, true);

		org.apache.avro.mapreduce.AvroMultipleOutputs.addNamedOutput(job, SessionType.SUBMITTER.getText(), AvroKeyValueOutputFormat.class, Schema.create(Schema.Type.STRING),Session.getClassSchema());
		org.apache.avro.mapreduce.AvroMultipleOutputs.addNamedOutput(job, SessionType.CPO.getText(), AvroKeyValueOutputFormat.class, Schema.create(Schema.Type.STRING),Session.getClassSchema());
		org.apache.avro.mapreduce.AvroMultipleOutputs.addNamedOutput(job, SessionType.CLICKER.getText(), AvroKeyValueOutputFormat.class, Schema.create(Schema.Type.STRING),Session.getClassSchema());
		org.apache.avro.mapreduce.AvroMultipleOutputs.addNamedOutput(job, SessionType.SHOWER.getText(), AvroKeyValueOutputFormat.class, Schema.create(Schema.Type.STRING),Session.getClassSchema());
		org.apache.avro.mapreduce.AvroMultipleOutputs.addNamedOutput(job, SessionType.VISITOR.getText(), AvroKeyValueOutputFormat.class, Schema.create(Schema.Type.STRING),Session.getClassSchema());
		org.apache.avro.mapreduce.AvroMultipleOutputs.addNamedOutput(job, SessionType.OTHER.getText(), AvroKeyValueOutputFormat.class, Schema.create(Schema.Type.STRING), Session.getClassSchema());

		//MultipleInputs.addInputPath(job, new Path(appArgs[0]),AvroKeyValueInputFormat.class,AvroMapper.class);
		//MultipleInputs.addInputPath(job, new Path(appArgs[1]),TextInputFormat.class,CSVMapper.class);
		FileInputFormat.addInputPaths(job, appArgs[0]);
		FileOutputFormat.setOutputPath(job, new Path(appArgs[1]));

		// Initiate the map-reduce job, and wait for completion.
		job.waitForCompletion(true);

		Job job1 = Job.getInstance(conf, "UserSessions1");
		job1.setJarByClass(UserSessions.class);
		job1.setInputFormatClass(AvroKeyValueInputFormat.class);
		job1.setMapperClass(ChainMapper.class);

		AvroJob.setMapOutputValueSchema(job1, ClickSubtypeStatisticsData.getClassSchema());
		AvroJob.setMapOutputKeySchema(job1, ClickSubtypeStatisticsKey.getClassSchema());
		AvroJob.setInputKeySchema(job1, Schema.create(Schema.Type.STRING));
		AvroJob.setInputValueSchema(job1, Session.getClassSchema());

		job1.setReducerClass(ChainReduce.class);
		job1.setOutputFormatClass(AvroKeyValueOutputFormat.class);
		AvroJob.setOutputKeySchema(job1, ClickSubtypeStatisticsKey.getClassSchema());
		AvroJob.setOutputValueSchema(job1, ClickSubtypeStatisticsData.getClassSchema());




		Job job2 = Job.getInstance(conf, "UserSessions2");
		job2.setJarByClass(UserSessions.class);
		job2.setInputFormatClass(AvroKeyValueInputFormat.class);
		job2.setMapperClass(ChainMapper.class);

		AvroJob.setMapOutputValueSchema(job2, ClickSubtypeStatisticsData.getClassSchema());
		AvroJob.setMapOutputKeySchema(job2, ClickSubtypeStatisticsKey.getClassSchema());
		AvroJob.setInputKeySchema(job2, Schema.create(Schema.Type.STRING));
		AvroJob.setInputValueSchema(job2, Session.getClassSchema());

		job2.setReducerClass(ChainReduce.class);
		job2.setOutputFormatClass(AvroKeyValueOutputFormat.class);
		AvroJob.setOutputKeySchema(job2, ClickSubtypeStatisticsKey.getClassSchema());
		AvroJob.setOutputValueSchema(job2, ClickSubtypeStatisticsData.getClassSchema());




		Job job3 = Job.getInstance(conf, "UserSessions3");
		job3.setJarByClass(UserSessions.class);
		job3.setInputFormatClass(AvroKeyValueInputFormat.class);
		job3.setMapperClass(ChainMapper.class);

		AvroJob.setMapOutputValueSchema(job3, ClickSubtypeStatisticsData.getClassSchema());
		AvroJob.setMapOutputKeySchema(job3, ClickSubtypeStatisticsKey.getClassSchema());
		AvroJob.setInputKeySchema(job3, Schema.create(Schema.Type.STRING));
		AvroJob.setInputValueSchema(job3, Session.getClassSchema());

		job3.setReducerClass(ChainReduce.class);
		job3.setOutputFormatClass(AvroKeyValueOutputFormat.class);
		AvroJob.setOutputKeySchema(job3, ClickSubtypeStatisticsKey.getClassSchema());
		AvroJob.setOutputValueSchema(job3, ClickSubtypeStatisticsData.getClassSchema());




		FileInputFormat.addInputPath(job1, new Path(appArgs[1] + "/clicker-m-00000.avro"));
		FileInputFormat.addInputPath(job1, new Path(appArgs[1] + "/clicker-m-00001.avro"));
		FileInputFormat.addInputPath(job1, new Path(appArgs[1] + "/clicker-m-00002.avro"));
		FileInputFormat.addInputPath(job1,new Path(appArgs[1]+"/clicker-m-00003.avro"));
		FileInputFormat.addInputPath(job1,new Path(appArgs[1]+"/clicker-m-00004.avro"));

		FileInputFormat.addInputPath(job2,new Path(appArgs[1]+"/cpo-m-00000.avro"));
		FileInputFormat.addInputPath(job2,new Path(appArgs[1]+"/cpo-m-00001.avro"));
		FileInputFormat.addInputPath(job2,new Path(appArgs[1]+"/cpo-m-00002.avro"));
		FileInputFormat.addInputPath(job2,new Path(appArgs[1]+"/cpo-m-00003.avro"));
		FileInputFormat.addInputPath(job2,new Path(appArgs[1]+"/cpo-m-00004.avro"));

		FileInputFormat.addInputPath(job3,new Path(appArgs[1]+"/submitter-m-00000.avro"));
		FileInputFormat.addInputPath(job3,new Path(appArgs[1]+"/submitter-m-00001.avro"));
		FileInputFormat.addInputPath(job3,new Path(appArgs[1]+"/submitter-m-00002.avro"));
		//FileInputFormat.addInputPath(job2,new Path(appArgs[1]+"submitter-m-00003.avro"));
		FileInputFormat.addInputPath(job3,new Path(appArgs[1]+"/submitter-m-00004.avro"));

		FileOutputFormat.setOutputPath(job1, new Path(appArgs[1] + "/Clicker"));
		FileOutputFormat.setOutputPath(job2, new Path(appArgs[1] + "/CPO"));
		FileOutputFormat.setOutputPath(job3, new Path(appArgs[1] + "/Submitter"));

		job1.submit();
		job2.submit();
		job3.submit();

		//job1.waitForCompletion(true);
		//job2.waitForCompletion(true);
		//job3.waitForCompletion(true);

		while(!(job1.isComplete() && job2.isComplete() && job3.isComplete())){

		}
		Job job4 = Job.getInstance(conf, "UserSessions4");
		job4.setJarByClass(UserSessions.class);
		job4.setInputFormatClass(AvroKeyValueInputFormat.class);
		job4.setMapperClass(AggrMapper.class);

		AvroJob.setMapOutputValueSchema(job4, ClickSubtypeStatisticsData.getClassSchema());
		AvroJob.setMapOutputKeySchema(job4, ClickSubtypeStatisticsKey.getClassSchema());
		AvroJob.setInputKeySchema(job4, ClickSubtypeStatisticsKey.getClassSchema());
		AvroJob.setInputValueSchema(job4, ClickSubtypeStatisticsData.getClassSchema());

		job4.setReducerClass(AggrReducer.class);
		job4.setOutputFormatClass(TextOutputFormat.class);
		AvroJob.setOutputKeySchema(job4, ClickSubtypeStatisticsKey.getClassSchema());
		AvroJob.setOutputValueSchema(job4, ClickSubtypeStatisticsData.getClassSchema());


		FileInputFormat.addInputPath(job4, new Path(appArgs[1] + "/Clicker/part-r-00000.avro"));
		FileInputFormat.addInputPath(job4, new Path(appArgs[1] + "/CPO/part-r-00000.avro"));
		FileInputFormat.addInputPath(job4, new Path(appArgs[1] + "/Submitter/part-r-00000.avro"));

		FileOutputFormat.setOutputPath(job4, new Path(appArgs[1] + "/Aggr"));

		job4.submit();
		job4.waitForCompletion(true);

		return 0;
	}

	public static void printClassPath() {
		ClassLoader cl = ClassLoader.getSystemClassLoader();
		URL[] urls = ((URLClassLoader) cl).getURLs();
		System.out.println("classpath BEGIN");
		for (URL url : urls) {
			System.out.println(url.getFile());
		}
		System.out.println("classpath END");
		System.out.flush();
	}
	/**
	 * The main method specifies the characteristics of the map-reduce job
	 * by setting values on the Job object, and then initiates the map-reduce
	 * job and waits for it to complete.
	 */
	public static void main(String[] args) throws Exception {
		printClassPath();
		int res = ToolRunner.run(new Configuration(), new UserSessions(), args);
		System.exit(res);
	}
}
