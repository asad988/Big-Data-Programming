package com.refactorlabs.cs378.sessions;

import com.sun.tools.javac.code.Attribute;
import com.sun.tools.javac.util.Convert;
import org.apache.avro.mapred.AvroKey;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.MRJobConfig;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.avro.mapred.AvroValue;
import org.apache.avro.mapreduce.AvroJob;
import java.net.URL;
import java.net.URLClassLoader;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.*;

import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
/**
 * Created by asad on 11/9/2015.
 */


public class ChainMapper extends Mapper<AvroKey<CharSequence>, AvroValue<Session>, AvroKey<ClickSubtypeStatisticsKey>, AvroValue<ClickSubtypeStatisticsData>> {

    @Override
    public void map(AvroKey<CharSequence> key, AvroValue<Session> value, Context context)
            throws IOException, InterruptedException {

        List<Event> event = new ArrayList<Event>();
        event = value.datum().getEvents();

        ClickSubtypeStatisticsKey.Builder myKey=ClickSubtypeStatisticsKey.newBuilder();
        ClickSubtypeStatisticsData.Builder myValue=ClickSubtypeStatisticsData.newBuilder();

        //stores session count
        long mysessions=1L;

        //stores count of each event subtype
        long alternative=0;
        long banner=0;
        long button=0;
        long dealer=0;
        long direction=0;
        long features=0;
        long vehicle=0;

        //used to check the session type
        boolean submit=false, click=false, CPO=false;

        for(Event myevent : event){
            if(myevent.getEventType()==EventType.EDIT || myevent.getEventType()==EventType.CONTACT_FORM_STATUS || myevent.getEventType()==(EventType.SUBMIT) || myevent.getEventType()==EventType.CHANGE){
                submit=true;
            }
            else if(myevent.getEventType().equals(EventType.ILMR_CPO)){
                CPO=true;
            }
            else if(myevent.getEventType().equals(EventType.CLICK)|| myevent.getEventType().equals(EventType.PLAY) || myevent.getEventType().equals(EventType.PRINT)){
                 click=true;
            }

            if(myevent.getEventType().equals(EventType.CLICK)){
                if(myevent.getEventSubtype().equals(EventSubtype.ALTERNATIVE)){
                    alternative++;
                }
                if(myevent.getEventSubtype().equals(EventSubtype.CONTACT_BANNER)){
                    banner++;
                }
                if(myevent.getEventSubtype().equals(EventSubtype.CONTACT_BUTTON)){
                    button++;
                }
                if(myevent.getEventSubtype().equals(EventSubtype.DEALER_PHONE)){
                    dealer++;
                }
                if(myevent.getEventSubtype().equals(EventSubtype.FEATURES)){
                    features++;
                }
                if(myevent.getEventSubtype().equals(EventSubtype.GET_DIRECTIONS)){
                    direction++;
                }
                if(myevent.getEventSubtype().equals(EventSubtype.VEHICLE_HISTORY)){
                    vehicle++;
                }
            }
           // mysessions++;
        }

        if(submit){
            myKey.setSessionType("SUBMITTER");
        }
        else if(CPO){
            myKey.setSessionType("ILMR_CPO");
        }
        else if(click){
            myKey.setSessionType("CLICKER");
        }



        if (alternative >= 0) {
            myKey.setClickSubtype("ALTERNATIVE");
            myValue.setSessionCount(mysessions);
            myValue.setTotalCount(alternative);
            myValue.setSumOfSquares(alternative * alternative);
            context.write(new AvroKey<ClickSubtypeStatisticsKey>(myKey.build()), new AvroValue<ClickSubtypeStatisticsData>(myValue.build()));
        }
        if (banner >= 0) {
            myKey.setClickSubtype("CONTACT_BANNER");
            myValue.setSessionCount(mysessions);
            myValue.setTotalCount(banner);
            myValue.setSumOfSquares(banner * banner);
            context.write(new AvroKey<ClickSubtypeStatisticsKey>(myKey.build()), new AvroValue<ClickSubtypeStatisticsData>(myValue.build()));
        }
        if (button >= 0) {
            myKey.setClickSubtype("CONTACT_BUTTON");
            myValue.setSessionCount(mysessions);
            myValue.setTotalCount(button);
            myValue.setSumOfSquares(button * button);
            context.write(new AvroKey<ClickSubtypeStatisticsKey>(myKey.build()), new AvroValue<ClickSubtypeStatisticsData>(myValue.build()));
        }
        if (features >= 0) {
            myKey.setClickSubtype("FEATURES_SECTION");
            myValue.setSessionCount(mysessions);
            myValue.setTotalCount(features);
            myValue.setSumOfSquares(features * features);
            context.write(new AvroKey<ClickSubtypeStatisticsKey>(myKey.build()), new AvroValue<ClickSubtypeStatisticsData>(myValue.build()));
        }
        if (dealer >= 0) {
            myKey.setClickSubtype("DEALER_PHONE");
            myValue.setSessionCount(mysessions);
            myValue.setTotalCount(dealer);
            myValue.setSumOfSquares(dealer * dealer);
            context.write(new AvroKey<ClickSubtypeStatisticsKey>(myKey.build()), new AvroValue<ClickSubtypeStatisticsData>(myValue.build()));
        }
        if (direction >= 0) {
            myKey.setClickSubtype("GET_DIRECTIONS");
            myValue.setSessionCount(mysessions);
            myValue.setTotalCount(direction);
            myValue.setSumOfSquares(direction * direction);
            context.write(new AvroKey<ClickSubtypeStatisticsKey>(myKey.build()), new AvroValue<ClickSubtypeStatisticsData>(myValue.build()));
        }
        if (vehicle >= 0) {
            myKey.setClickSubtype("VEHICLE_HISTORY");
            myValue.setSessionCount(mysessions);
            myValue.setTotalCount(vehicle);
            myValue.setSumOfSquares(vehicle * vehicle);
            context.write(new AvroKey<ClickSubtypeStatisticsKey>(myKey.build()), new AvroValue<ClickSubtypeStatisticsData>(myValue.build()));
        }

    }
}
