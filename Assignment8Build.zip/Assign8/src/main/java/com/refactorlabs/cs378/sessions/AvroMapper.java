package com.refactorlabs.cs378.sessions;

import com.sun.tools.javac.code.Attribute;
import com.sun.tools.javac.util.Convert;
import org.apache.avro.mapred.AvroKey;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.MRJobConfig;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.avro.mapred.AvroValue;
import org.apache.avro.mapreduce.AvroJob;
import java.net.URL;
import java.net.URLClassLoader;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.*;

import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/**
 * Created by asad on 10/31/2015.
 */

//The Map class for avro file.  Extends class Mapper, provided by Hadoop.
public class AvroMapper extends Mapper<AvroKey<CharSequence>, AvroValue<Session>, AvroKey<CharSequence>, AvroValue<Session>> {

        /**
         * Counter group for the mapper.  Individual counters are grouped for the mapper.
         */
        private static final String MAPPER_COUNTER_GROUP = "Mapper Counts";

        /**
         * Local variable "word" will contain the word identified in the input.
         * The Hadoop Text object is mutable, so we can reuse the same object and
         * simply reset its value as each word in the input is encountered.
         */
        private Text word = new Text();

    private Random rands = new Random();

    private Double percentage;

    private org.apache.avro.mapreduce.AvroMultipleOutputs multipleOutputs;

    @Override
    protected void setup(Context context) {
        multipleOutputs = new org.apache.avro.mapreduce.AvroMultipleOutputs(context);
        percentage = .1/100;
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        multipleOutputs.close();
    }

    int temp;

    @Override
    public void map(AvroKey<CharSequence> key, AvroValue<Session> value, Context context)
                throws IOException, InterruptedException {
        List<Event> event = new ArrayList<Event>();
        event = value.datum().getEvents();
        boolean submit=false;
        boolean CPO=false;
        boolean Click=false;
        boolean Show=false;
        boolean visit=false;

        for (Event myevent : event) {
            if (myevent.getEventType()==EventType.EDIT || myevent.getEventType()==EventType.CONTACT_FORM_STATUS || myevent.getEventType()==(EventType.SUBMIT) || myevent.getEventType()==EventType.CHANGE) {
                temp=1;
                submit=true;
            } else if (myevent.getEventType().equals(EventType.ILMR_CPO)) {
                temp=2;
                CPO=true;
            } else if (myevent.getEventType().equals(EventType.CLICK) || myevent.getEventType().equals(EventType.PLAY) || myevent.getEventType().equals(EventType.PRINT)) {
                temp=3;
                Click=true;
            } else if (myevent.getEventType().equals(EventType.SHOW)) {
                temp=4;
                Show=true;
            } else if (myevent.getEventType().equals(EventType.VISIT)) {
                temp=5;
                visit=true;
            } else {

            }
        }

        if(submit){
            multipleOutputs.write(SessionType.SUBMITTER.getText(), key, value);
        }
        else if(CPO){
            multipleOutputs.write(SessionType.CPO.getText(),key,value);
        }
        else if(Click){
            multipleOutputs.write(SessionType.CLICKER.getText(),key,value);
        }
        else if(Show){
            multipleOutputs.write(SessionType.SHOWER.getText(),key,value);
        }
        else if(visit){
            multipleOutputs.write(SessionType.VISITOR.getText(),key,value);
        }
        else{
            if(rands.nextDouble() < percentage) {
                multipleOutputs.write(SessionType.OTHER.getText(),key,value);
            }
            else{
                context.getCounter(MAPPER_COUNTER_GROUP, "Discarded").increment(1L);
            }
        }
        /*
        switch (temp){
            case 1: multipleOutputs.write(SessionType.SUBMITTER.getText(),key,value); break;
            case 2: multipleOutputs.write(SessionType.CPO.getText(),key,value); break;
            case 3: multipleOutputs.write(SessionType.CLICKER.getText(),key,value); break;
            case 4: multipleOutputs.write(SessionType.SHOWER.getText(),key,value); break;
            case 5: multipleOutputs.write(SessionType.VISITOR.getText(),key,value); break;
            case 6: multipleOutputs.write(SessionType.OTHER.getText(),key,value);break;
            default: break;
        }
        */
        //context.getCounter(MAPPER_COUNTER_GROUP, store).increment(1L);

    }

}
