package com.refactorlabs.cs378.assign2;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.IOException;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Map;


public class WordStatistics {

	//used for mapper value output and combiner value input and output
	public static class LongArrayWritable extends ArrayWritable{

		public LongArrayWritable() {
		    super(LongWritable.class);
		}

		public long[] getValueArray() {
			org.apache.hadoop.io.Writable[] wValues = get();
			long[] values = new long[wValues.length];
			for (int i = 0; i < values.length; i++) {
				values[i] = ((LongWritable)wValues[i]).get();
			}
			return values;
		}

	}

	//used for reducer value output
	public static class DoubleArrayWritable extends ArrayWritable{

		public DoubleArrayWritable() {
			super(DoubleWritable.class);
		}

		public double[] getValueArray() {
			org.apache.hadoop.io.Writable[] wValues = get();
			double[] values = new double[wValues.length];
			for (int i = 0; i < values.length; i++) {
				values[i] = ((DoubleWritable)wValues[i]).get();
			}
			return values;
		}

		@Override
		public String toString() {
			double[] values = getValueArray();
			return Double.toString(values[0])+","+ Double.toString(values[1])+"," + Double.toString(values[2]);
		}

	}
	/**
	 * Each count output from the map() function is "1", so to minimize small
	 * object creation we can use a constant for this output value/object.
	 */
	public final static LongWritable ONE = new LongWritable(1L);


	//Combiner Class
	public static class Combiner extends Reducer<LongWritable, Text, Text, LongArrayWritable>{
		public void reduce(Text key, Iterable<LongArrayWritable> values, Context context)
				throws IOException, InterruptedException {
			long sum = 0L;
			long[] myArrayVal = new long[4];
			LongArrayWritable outputs = new LongArrayWritable();

			for (LongArrayWritable value : values) {
				long sumation[] = value.getValueArray();
				for(int i=0; i<sumation.length; i++) {
					myArrayVal[i] += sumation[i];
				}
			}

			Writable[] writableArray = new Writable[3];
			//store values in doublearraywritable to be output using toString in doublearraywritable
			writableArray[0]=new DoubleWritable(myArrayVal[0]);
			writableArray[1]=new DoubleWritable(myArrayVal[1]);
			writableArray[2]=new DoubleWritable(myArrayVal[2]);
			outputs.set(writableArray);

			//Write the output to context
			context.write(key, outputs);

		}

	}

	/**
	 * The Map class for word count.  Extends class Mapper, provided by Hadoop.
	 * This class defines the map() function for the word count example.
	 *
	 *
	 */

	public static class MapClass extends Mapper<LongWritable, Text, Text, LongArrayWritable> {

		/**
		 * Counter group for the mapper.  Individual counters are grouped for the mapper.
		 */
		private static final String MAPPER_COUNTER_GROUP = "Mapper Counts";

		/**
		 * Local variable "word" will contain the word identified in the input.
		 * The Hadoop Text object is mutable, so we can reuse the same object and
		 * simply reset its value as each word in the input is encountered.
		 */
		private Text word = new Text();

		@Override
		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
			String line = value.toString();
			StringTokenizer tokenizer = new StringTokenizer(line);
			//store key and number of occurences
            Map<String,Integer>wordCountMap=new HashMap<String,Integer>();
            while (tokenizer.hasMoreTokens()) {
                String next = tokenizer.nextToken();
				//remove punctuations and make all words lower case
				next=next.replaceAll("[^a-zA-Z0-9]","");
				next=next.toLowerCase();
                Integer Count = wordCountMap.get(next);
				//Count tracks how many times a word is in a paragraph
                if(wordCountMap.containsKey(next)) {
                    wordCountMap.put(next, Count.intValue()+1);
                }
                else{
                    wordCountMap.put(next, 1);
                }
            }
			context.getCounter(MAPPER_COUNTER_GROUP, "Input Lines").increment(1L);

            LongArrayWritable MapArrayVal = new LongArrayWritable();

			for(String next : wordCountMap.keySet()) {
				word.set(next);
                Writable[] writableArray = new Writable[3];
				//store values in longarraywritable
                writableArray[0]=new LongWritable(1L);
                Integer Count = wordCountMap.get(next);
                writableArray[1]=new LongWritable(Count);
                writableArray[2]=new LongWritable(Count * Count);
                MapArrayVal.set(writableArray);
				context.write(word,MapArrayVal);
				context.getCounter(MAPPER_COUNTER_GROUP, "Words Out").increment(1L);
			}
		}
	}

	/**
	 * The Reduce class for word count.  Extends class Reducer, provided by Hadoop.
	 * This class defines the reduce() function for the word count example.
	 */
	public static class ReduceClass extends Reducer<Text, LongArrayWritable, Text, DoubleArrayWritable> {

		/**
		 * Counter group for the reducer.  Individual counters are grouped for the reducer.
		 */
		private static final String REDUCER_COUNTER_GROUP = "Reducer Counts";

		@Override
		public void reduce(Text key, Iterable<LongArrayWritable> values, Context context)
				throws IOException, InterruptedException {
			long sum = 0L;
            double[] myArrayVal = new double[4];

			context.getCounter(REDUCER_COUNTER_GROUP, "Words Out").increment(1L);

			for (LongArrayWritable value : values) {
				long sumation[] = value.getValueArray();
				for(int i=0; i<sumation.length; i++) {
					myArrayVal[i] += sumation[i];
				}
			}

			//calculate mean and variance
            double mean = myArrayVal[1]/myArrayVal[0];
            double var = (myArrayVal[2]/myArrayVal[0]) - (mean * mean);

			DoubleArrayWritable outputs = new DoubleArrayWritable();
			Writable[] writableArray = new Writable[3];
			//store values in doublearraywritable to be output using toString in doublearraywritable
			writableArray[0]=new DoubleWritable(myArrayVal[0]);
			writableArray[1]=new DoubleWritable(mean);
			writableArray[2]=new DoubleWritable(var);
			outputs.set(writableArray);

            //Write the output to context
            context.write(key, outputs);

		}
	}

	/**
	 * The main method specifies the characteristics of the map-reduce job
	 * by setting values on the Job object, and then initiates the map-reduce
	 * job and waits for it to complete.
	 */
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		String[] appArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

		Job job = new Job(conf, "WordStatistics");
		// Identify the JAR file to replicate to all machines.
        job.setJarByClass(WordStatistics.class);

		// Set the output key and value types (for map and reduce).

		//map has different output values
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(LongArrayWritable.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(DoubleArrayWritable.class);
        //job.setMapOutputKeyClass(Text.class);
        //job.setMapOutputValueClass(LongArrayWritable.class);

		// Set the map and reduce classes.
		job.setMapperClass(MapClass.class);
		job.setReducerClass(ReduceClass.class);
		job.setCombinerClass(Combiner.class);

		// Set the input and output file formats.
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		// Grab the input file and output directory from the command line.
		FileInputFormat.addInputPath(job, new Path(appArgs[0]));
		FileOutputFormat.setOutputPath(job, new Path(appArgs[1]));

		// Initiate the map-reduce job, and wait for completion.
		job.waitForCompletion(true);
	}
}
