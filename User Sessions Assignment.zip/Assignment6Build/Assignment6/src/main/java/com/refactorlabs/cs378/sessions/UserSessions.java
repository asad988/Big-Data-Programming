package com.refactorlabs.cs378.sessions;

import com.sun.tools.javac.code.Attribute;
import com.sun.tools.javac.util.Convert;
import org.apache.avro.mapred.AvroKey;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.MRJobConfig;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.avro.mapred.AvroValue;
import org.apache.avro.mapreduce.AvroJob;
import java.net.URL;
import java.net.URLClassLoader;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.*;

import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


public class UserSessions extends Configured implements Tool{

	/**
	 * Each count output from the map() function is "1", so to minimize small
	 * object creation we can use a constant for this output value/object.
	 */
	public final static LongWritable ONE = new LongWritable(1L);

	/**
	 * The Map class.  Extends class Mapper, provided by Hadoop.
	 */
	public static class MapClass extends Mapper<LongWritable, Text, Text, AvroValue<Session>> {

		/**
		 * Counter group for the mapper.  Individual counters are grouped for the mapper.
		 */
		private static final String MAPPER_COUNTER_GROUP = "Mapper Counts";

		/**
		 * Local variable "word" will contain the word identified in the input.
		 * The Hadoop Text object is mutable, so we can reuse the same object and
		 * simply reset its value as each word in the input is encountered.
		 */
		private Text word = new Text();



		@Override
		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {

			String line = value.toString();
			String[] col={"user_id","event_type","page","referrer","referring_domain","event_timestamp","city","region","vin","vehicle_condition","year","make","model","trim","body_style","subtrim","cab_style","initial_price","mileage","mpg","exterior_color","interior_color","engine_displacement","engine","transmission","drive_type","fuel","image_count","initial_carfax_free_report","carfax_one_owner","initial_cpo","features"};
			StringTokenizer tokenizer = new StringTokenizer(line);
			String token;
			context.getCounter(MAPPER_COUNTER_GROUP, "Input Lines").increment(1L);

			String[] store = line.split("\t");
			Session.Builder Sbuilder = Session.newBuilder();
			Sbuilder.setUserId(store[0]);
			Event.Builder Ebuilder = Event.newBuilder();


			String temp1 = store[1].toLowerCase();
			if(temp1.contains("change")){
				Ebuilder.setEventType(EventType.valueOf("CHANGE"));
				Ebuilder.setEventSubtype(EventSubtype.valueOf("CONTACT_FORM_TYPE"));
			}
			else if(temp1.contains("error")){
				Ebuilder.setEventType(EventType.valueOf("CONTACT_FORM_STATUS"));
				Ebuilder.setEventSubtype(EventSubtype.valueOf("ERROR"));
			}
			else if(temp1.contains("success")){
				Ebuilder.setEventType(EventType.valueOf("CONTACT_FORM_STATUS"));
				Ebuilder.setEventSubtype(EventSubtype.valueOf("ERROR"));
			}
			else if(temp1.contains("click")){
				Ebuilder.setEventType(EventType.valueOf("CLICK"));
				if(temp1.contains("alternative")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("ALTERNATIVE"));
				}
				if(temp1.contains("banner")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("CONTACT_BANNER"));
				}
				if(temp1.contains("button")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("CONTACT_BUTTON"));
				}
				if(temp1.contains("dealer")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("DEALER_PHONE"));
				}
				if(temp1.contains("features")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("FEATURES_SECTION"));
				}
				if(temp1.contains("directions")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("GET_DIRECTIONS"));
				}
				if(temp1.contains("history")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("VEHICLE_HISTORY"));
				}

			}
			else if(temp1.contains("edit")){
				Ebuilder.setEventType(EventType.valueOf("DISPLAY"));
				Ebuilder.setEventSubtype(EventSubtype.valueOf("CONTACT_FORM"));
			}
			else if(temp1.contains("play")){
				Ebuilder.setEventType(EventType.valueOf("PLAY"));
				Ebuilder.setEventSubtype(EventSubtype.valueOf("ILMR_VIDEO"));
			}
			else if(temp1.contains("print")){
				Ebuilder.setEventType(EventType.valueOf("PRINT"));
				Ebuilder.setEventSubtype(EventSubtype.valueOf("ILMR"));
			}
			else if(temp1.contains("show")){
				Ebuilder.setEventType(EventType.valueOf("SHOW"));
				if(temp1.contains("badge")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("BADGE_DETAIL"));
				}
				else{
					Ebuilder.setEventSubtype(EventSubtype.valueOf("PHOTO_MODAL"));
				}
			}
			else if(temp1.contains("submit")){
				Ebuilder.setEventType(EventType.valueOf("SUBMIT"));
				Ebuilder.setEventSubtype(EventSubtype.valueOf("CONTACT_FORM"));
			}
			else if(temp1.contains("visit")){
				Ebuilder.setEventType(EventType.valueOf("VISIT"));
				if(temp1.contains("alternatives")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("ALTERNATIVES"));
				}
				if(temp1.contains("badges")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("BADGES"));
				}
				if(temp1.contains("contact")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("CONTACT_FORM"));
				}
				if(temp1.contains("features")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("FEATURES"));
				}
				if(temp1.contains("history")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("VEHICLE_HISTORY"));
				}
				if(temp1.contains("market")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("MARKET_REPORT_LISTING"));
				}
			}
			else if(temp1.contains("display")){
				Ebuilder.setEventType(EventType.valueOf("DISPLAY"));
				if(temp1.contains("alternatives")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("ALTERNATIVES"));
				}
				else{
					Ebuilder.setEventSubtype(EventSubtype.valueOf("ILMR_REPORT_LISTING"));
				}
			}
			else if(temp1.contains("cpo")){
				Ebuilder.setEventType(EventType.valueOf("ILMR_CPO"));
				if(temp1.contains("financing")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("FINANCING"));
				}
				if(temp1.contains("inspection")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("INSPECTION"));
				}
				if(temp1.contains("roadside")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("ROADSIDE"));
				}
				if(temp1.contains("sirius")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("SIRIUS"));
				}
				if(temp1.contains("warranty")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("WARRANTY"));
				}
				if(temp1.contains("more")){
					Ebuilder.setEventSubtype(EventSubtype.valueOf("SEE_MORE"));
				}

			}


			Ebuilder.setPage(store[2]);
			Ebuilder.setReferrer(store[3]);
			Ebuilder.setReferringDomain(store[4]);
			Ebuilder.setEventTime(store[5]);
			Ebuilder.setCity(store[6]);
			Ebuilder.setRegion(store[7]);
			Ebuilder.setVin((store[8]));
			Ebuilder.setVehicleCondition(VehicleCondition.valueOf(store[9]));
			Ebuilder.setYear(Integer.parseInt(store[10]));
			Ebuilder.setMake(store[11]);
			Ebuilder.setModel(store[12]);
			Ebuilder.setTrim(store[13]);
			Ebuilder.setBodyStyle(BodyStyle.valueOf(store[14]));
			Ebuilder.setSubtrim(store[15]);

			if(store[16].contains("null")){
				Ebuilder.setCabStyle(null);
			}
			else if(store[16].contains("Regular")){
				Ebuilder.setCabStyle(CabStyle.valueOf("RegularCab"));
			}
			else {
				Ebuilder.setCabStyle(CabStyle.valueOf("CrewCab"));
			}

			Ebuilder.setInitialPrice(Double.parseDouble(store[17]));
			Ebuilder.setMileage(Integer.parseInt(store[18]));
			Ebuilder.setMpg(Integer.parseInt(store[19]));
			Ebuilder.setExteriorColor(store[20]);
			Ebuilder.setInteriorColor(store[21]);
			Ebuilder.setEngineDisplacement(store[22]);
			Ebuilder.setEngine(store[23]);
			Ebuilder.setTransmission(store[24]);
			Ebuilder.setDriveType(store[25]);
			Ebuilder.setFuel(store[26]);
			Ebuilder.setImageCount(Integer.parseInt(store[27]));
			Ebuilder.setInitialCarfaxFreeReport(store[28]);
			Ebuilder.setCarfaxOneOwner(store[29]);
			Ebuilder.setInitialCpo(store[30]);

			String[] Features = store[31].split(":");
			List<CharSequence> fvalue = new ArrayList<CharSequence>();
			for(int i=0; i<Features.length; i++){
				fvalue.add(Features[i]);
			}
			Ebuilder.setFeatures(fvalue);
			List<Event> event = new ArrayList<Event>();
			event.add(Ebuilder.build());
			Sbuilder.setEvents(event);

			word.set(store[0]);
			context.write(word, new AvroValue<Session>(Sbuilder.build()));
			context.getCounter(MAPPER_COUNTER_GROUP, "Words Out").increment(1L);
		}
	}

	/**
	 * The Reduce class for word count.  Extends class Reducer, provided by Hadoop.
	 * This class defines the reduce() function for the word count example.
	 */
	public static class ReduceClass extends Reducer<Text, AvroValue<Session>, AvroKey<CharSequence>, AvroValue<Session>> {

		/**
		 * Counter group for the reducer.  Individual counters are grouped for the reducer.
		 */
		private static final String REDUCER_COUNTER_GROUP = "Reducer Counts";

		@Override
		public void reduce(Text key, Iterable<AvroValue<Session>> values, Context context)
				throws IOException, InterruptedException {

			context.getCounter(REDUCER_COUNTER_GROUP, "Words Out").increment(1L);

			Session.Builder builder = Session.newBuilder();
			List<Event> allEvents = new ArrayList<Event>();
			builder.setUserId(key.toString());

			for (AvroValue<Session> value : values) {
				List<Event> event = value.datum().getEvents();
				for (int i=0; i<event.size(); i++){
					allEvents.add(Event.newBuilder(event.get(i)).build());
				}
			}
			builder.setEvents(allEvents);
			CharSequence myKey = key.toString();

			context.write(new AvroKey<CharSequence>(myKey), new AvroValue<Session>(builder.build()));
		}
	}

	public int run(String[] args) throws Exception {
		if (args.length != 2) {
			System.err.println("Usage: WordStatistics <input path> <output path>");
			return -1;
		}

		Configuration conf = getConf();

		// Use this JAR first in the classpath (We also set a bootstrap script in AWS)
		conf.setBoolean(MRJobConfig.MAPREDUCE_JOB_USER_CLASSPATH_FIRST, true);

		Job job = Job.getInstance(conf, "UserSessions");
		String[] appArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

		// Identify the JAR file to replicate to all machines.
		job.setJarByClass(UserSessions.class);

		// Specify the Map
		job.setInputFormatClass(TextInputFormat.class);
		job.setMapperClass(MapClass.class);
		job.setMapOutputKeyClass(Text.class);
		AvroJob.setMapOutputValueSchema(job, Session.getClassSchema());

		// Specify the Reduce
		job.setOutputFormatClass(TextOutputFormat.class);
		job.setReducerClass(ReduceClass.class);
		job.setOutputKeyClass(CharSequence.class);
		AvroJob.setOutputValueSchema(job, Session.getClassSchema());

		// Grab the input file and output directory from the command line.
		FileInputFormat.addInputPaths(job, appArgs[0]);
		FileOutputFormat.setOutputPath(job, new Path(appArgs[1]));

		// Initiate the map-reduce job, and wait for completion.
		job.waitForCompletion(true);

		return 0;
	}

	public static void printClassPath() {
		ClassLoader cl = ClassLoader.getSystemClassLoader();
		URL[] urls = ((URLClassLoader) cl).getURLs();
		System.out.println("classpath BEGIN");
		for (URL url : urls) {
			System.out.println(url.getFile());
		}
		System.out.println("classpath END");
		System.out.flush();
	}
	/**
	 * The main method specifies the characteristics of the map-reduce job
	 * by setting values on the Job object, and then initiates the map-reduce
	 * job and waits for it to complete.
	 */
	public static void main(String[] args) throws Exception {
		printClassPath();
		int res = ToolRunner.run(new Configuration(), new UserSessions(), args);
		System.exit(res);
	}
}
